"use client"

import { useState, useEffect } from "react"
import { MiniKit } from "@worldcoin/minikit-js"
import Image from "next/image"
import { ethers } from "ethers"
import { useLanguage } from "@/lib/languageContext"

type SendTPFModalProps = {
  isOpen: boolean
  onClose: () => void
  walletAddress: string
  tokenLogo: string
  onSuccess?: (txId: string) => void
}

export default function SendTPFModal({ isOpen, onClose, walletAddress, tokenLogo, onSuccess }: SendTPFModalProps) {
  const { t } = useLanguage()
  const [recipientAddress, setRecipientAddress] = useState("")
  const [amount, setAmount] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [txId, setTxId] = useState<string | null>(null)
  const [validationErrors, setValidationErrors] = useState<{
    recipient?: string
    amount?: string
  }>({})

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setRecipientAddress("")
      setAmount("")
      setError(null)
      setSuccess(false)
      setTxId(null)
      setValidationErrors({})
    }
  }, [isOpen])

  // Handle outside click to close modal
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (target.classList.contains("modal-backdrop")) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("click", handleOutsideClick)
    }

    return () => {
      document.removeEventListener("click", handleOutsideClick)
    }
  }, [isOpen, onClose])

  // Handle ESC key to close modal
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("keydown", handleEscKey)
    }

    return () => {
      document.removeEventListener("keydown", handleEscKey)
    }
  }, [isOpen, onClose])

  // Validate form fields
  const validateForm = (): boolean => {
    const errors: {
      recipient?: string
      amount?: string
    } = {}

    // Validate recipient address
    if (!recipientAddress) {
      errors.recipient = t("recipient_required", "Recipient address is required")
    } else if (!ethers.isAddress(recipientAddress)) {
      errors.recipient = t("invalid_eth_address", "Invalid Ethereum address format")
    }

    // Validate amount
    if (!amount) {
      errors.amount = t("amount_required", "Amount is required")
    } else if (isNaN(Number(amount)) || Number(amount) <= 0) {
      errors.amount = t("amount_positive", "Amount must be a positive number")
    }

    setValidationErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleSendTPF = async () => {
    // Validate form
    if (!validateForm()) {
      return
    }

    if (!MiniKit.isInstalled()) {
      setError(t("minikit_not_installed", "MiniKit is not installed"))
      return
    }

    try {
      setIsLoading(true)
      setError(null)

      // Endereço do contrato TPF na World Chain
      const tokenAddress = "0x834a73c0a83F3BCe349A116FFB2A4c2d1C651E45"

      // Converter o valor para wei (assumindo 18 decimais para TPF)
      const amountValue = Number.parseFloat(amount)
      const amountInWei = BigInt(Math.floor(amountValue * 10 ** 18)).toString()

      console.log(`Sending ${amount} TPF (${amountInWei} in wei) to ${recipientAddress}`)

      // ABI mínimo para a função transfer do ERC20
      const transferAbi = [
        {
          inputs: [
            { name: "recipient", type: "address" },
            { name: "amount", type: "uint256" },
          ],
          name: "transfer",
          outputs: [{ name: "", type: "bool" }],
          stateMutability: "nonpayable",
          type: "function",
          // Adicionar o seletor de função que você compartilhou
          method_id: "0xa9059cbb",
        },
      ]

      // Usar o método sendTransaction do MiniKit
      const { finalPayload } = await MiniKit.commandsAsync.sendTransaction({
        transaction: [
          {
            address: tokenAddress,
            abi: transferAbi,
            functionName: "transfer",
            args: [recipientAddress, amountInWei],
          },
        ],
      })

      console.log("Transaction response:", finalPayload)

      if (finalPayload.status === "error") {
        throw new Error(
          finalPayload.message || finalPayload.description || t("transaction_failed", "Transaction failed"),
        )
      }

      // Definir estado de sucesso
      setSuccess(true)
      setTxId(finalPayload.transaction_id || "")

      // Chamar callback onSuccess se fornecido
      if (onSuccess && finalPayload.transaction_id) {
        onSuccess(finalPayload.transaction_id)
      }

      // Fechar modal após 3 segundos em caso de sucesso
      setTimeout(() => {
        onClose()
      }, 3000)
    } catch (error) {
      console.error("Error sending TPF:", error)

      // Verificar se o erro é relacionado a contrato não reconhecido
      const errorMessage = error instanceof Error ? error.message : t("failed_to_send_tpf", "Failed to send TPF")

      if (errorMessage.includes("unrecognized contract") || errorMessage.includes("Invalid Token")) {
        setError(
          t("error_sending_tpf", "There was an error sending TPF. Please try again or use the worldcoin app directly."),
        )
      } else {
        setError(errorMessage)
      }
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop bg-black/70 backdrop-blur-sm">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-md p-5 shadow-2xl animate-fadeIn">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-white">{t("send", "Send")} TPF</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
            aria-label={t("close", "Close")}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex items-center mb-6 bg-gray-800 p-3 rounded-lg">
          <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-700 flex-shrink-0 mr-3">
            <Image
              src={tokenLogo || "/placeholder.svg"}
              alt="TPF logo"
              width={40}
              height={40}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="font-medium text-white">TPF</div>
            <div className="text-xs text-gray-400">TPulseFi</div>
          </div>
        </div>

        {success ? (
          <div className="bg-green-900/30 border border-green-700 rounded-lg p-4 text-center mb-4">
            <div className="flex justify-center mb-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#4CAF50"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
            </div>
            <p className="text-green-300 text-sm">{t("transaction_sent_success", "Transaction sent successfully!")}</p>
            {txId && (
              <p className="text-xs text-green-200 mt-1 font-mono bg-green-900/30 p-1 rounded overflow-hidden text-ellipsis">
                TX: {txId}
              </p>
            )}
            <div className="mt-3">
              <a
                href={`https://worldscan.org/tx/${txId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-blue-400 hover:text-blue-300 underline"
              >
                {t("view_on_worldscan", "View on WorldScan")}
              </a>
            </div>
          </div>
        ) : (
          <>
            {error && (
              <div className="text-red-400 text-sm p-2 bg-red-900/20 rounded-lg border border-red-800/50 mb-4">
                {error}
              </div>
            )}
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault()
                handleSendTPF()
              }}
            >
              <div>
                <label htmlFor="recipient" className="block text-sm font-medium text-gray-300 mb-1">
                  {t("to", "To")} <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  id="recipient"
                  value={recipientAddress}
                  onChange={(e) => setRecipientAddress(e.target.value)}
                  placeholder="0x..."
                  className={`w-full px-3 py-2 bg-gray-800 border rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    validationErrors.recipient ? "border-red-500" : "border-gray-700"
                  }`}
                />
                {validationErrors.recipient && (
                  <p className="mt-1 text-xs text-red-400">{validationErrors.recipient}</p>
                )}
              </div>

              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-300 mb-1">
                  {t("amount", "Amount")} <span className="text-red-400">*</span>
                </label>
                <input
                  type="number"
                  id="amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.0"
                  min="0"
                  step="0.01"
                  className={`w-full px-3 py-2 bg-gray-800 border rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    validationErrors.amount ? "border-red-500" : "border-gray-700"
                  }`}
                />
                {validationErrors.amount && <p className="mt-1 text-xs text-red-400">{validationErrors.amount}</p>}
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-gray-700 text-white rounded-lg mr-2 hover:bg-gray-600 transition-colors"
                >
                  {t("cancel", "Cancel")}
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:opacity-90 transition-colors flex items-center"
                >
                  {isLoading ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      {t("sending", "Sending...")}
                    </>
                  ) : (
                    t("send", "Send")
                  )}
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
