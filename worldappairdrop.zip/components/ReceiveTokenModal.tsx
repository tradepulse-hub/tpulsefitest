"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useLanguage } from "@/lib/languageContext"

type ReceiveTokenModalProps = {
  isOpen: boolean
  onClose: () => void
  walletAddress: string
  tokenSymbol: string
  tokenLogo: string
  tokenName: string
}

export default function ReceiveTokenModal({
  isOpen,
  onClose,
  walletAddress,
  tokenSymbol,
  tokenLogo,
  tokenName,
}: ReceiveTokenModalProps) {
  const { t } = useLanguage()
  const [copySuccess, setCopySuccess] = useState(false)

  // Handle outside click to close modal
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (target.classList.contains("modal-backdrop")) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("click", handleOutsideClick)
    }

    return () => {
      document.removeEventListener("click", handleOutsideClick)
    }
  }, [isOpen, onClose])

  // Handle ESC key to close modal
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("keydown", handleEscKey)
    }

    return () => {
      document.removeEventListener("keydown", handleEscKey)
    }
  }, [isOpen, onClose])

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(walletAddress)
      setCopySuccess(true)
      setTimeout(() => setCopySuccess(false), 2000)
    } catch (err) {
      console.error("Failed to copy: ", err)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop bg-black/70 backdrop-blur-sm">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-md p-5 shadow-2xl animate-fadeIn">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-white">
            {t("receive", "Receive")} {tokenSymbol}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
            aria-label={t("close", "Close")}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex items-center mb-6 bg-gray-800 p-3 rounded-lg">
          <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-700 flex-shrink-0 mr-3">
            <Image
              src={tokenLogo || "/placeholder.svg"}
              alt={`${tokenSymbol} logo`}
              width={40}
              height={40}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="font-medium text-white">{tokenSymbol}</div>
            <div className="text-xs text-gray-400">{tokenName}</div>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="bg-gray-800 p-6 rounded-lg shadow-md flex flex-col items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="48"
              height="48"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-blue-400 mb-3"
            >
              <path d="M12 20h9"></path>
              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
            </svg>
            <h3 className="text-lg font-medium text-white mb-2">{t("in_development", "In Development")}</h3>
            <p className="text-sm text-gray-300 text-center">
              {t("qr_code_coming_soon", "QR code functionality coming soon. Please use the wallet address below.")}
            </p>
          </div>

          <div className="w-full bg-gray-800 p-3 rounded-lg flex items-center justify-between">
            <div className="font-mono text-sm text-gray-300 truncate max-w-[80%]">{walletAddress}</div>
            <button
              onClick={copyToClipboard}
              className="ml-2 p-1.5 bg-gray-700 hover:bg-gray-600 rounded-md transition-colors"
              title={t("copy_address", "Copy address")}
            >
              {copySuccess ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-green-400"
                >
                  <path d="M20 6L9 17l-5-5" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-gray-400"
                >
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                  <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" />
                </svg>
              )}
            </button>
          </div>

          <div className="text-center text-sm text-gray-400 mt-2">
            <p>
              {t("copy_address_to_receive", "Copy the address above to receive")} {tokenSymbol}{" "}
              {t("on_worldchain", "on Worldchain")}.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:opacity-90 transition-colors"
          >
            {t("close", "Close")}
          </button>
        </div>
      </div>
    </div>
  )
}
