"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import SendTokenModal from "./SendTokenModal"
import SendTPFModal from "./SendTPFModal"
import ReceiveTokenModal from "./ReceiveTokenModal"
import TokenDetailModal from "./TokenDetailModal"
import { useLanguage } from "@/lib/languageContext"

type TokenWalletProps = {
  walletAddress: string
}

type TokenInfo = {
  symbol: string
  name: string
  quantity: string | null
  gradient: string
  logo: string
  loading?: boolean
  error?: string
  details?: string
  address: string
  price?: number
  priceSource?: string
}

export default function TokenWallet({ walletAddress }: TokenWalletProps) {
  const { t } = useLanguage()
  const [tokens, setTokens] = useState<TokenInfo[]>([
    {
      symbol: "TPF",
      name: "TPulseFi",
      quantity: null,
      gradient: "from-blue-500 to-purple-600",
      logo: "/images/tpf-logo.png",
      loading: true,
      address: "0x834a73c0a83F3BCe349A116FFB2A4c2d1C651E45",
    },
    {
      symbol: "WLD",
      name: "WorldCoin",
      quantity: null,
      gradient: "from-green-500 to-blue-600",
      logo: "/images/worldcoin-logo.jpeg",
      loading: true,
      address: "0x2cFc85d8E48F8EAB294be644d9E25C3030863003",
    },
  ])
  const [isLoading, setIsLoading] = useState(true)
  const [refreshTrigger, setRefreshTrigger] = useState(0)
  const [copySuccess, setCopySuccess] = useState(false)
  const [selectedToken, setSelectedToken] = useState<TokenInfo | null>(null)
  const [isSendModalOpen, setIsSendModalOpen] = useState(false)
  const [isSendTPFModalOpen, setIsSendTPFModalOpen] = useState(false)
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false)
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false)

  useEffect(() => {
    const fetchTokenBalances = async () => {
      if (!walletAddress) return

      setIsLoading(true)

      // Initialize tokens with loading state
      setTokens((prev) =>
        prev.map((token) => ({
          ...token,
          loading: true,
          error: undefined,
          details: undefined,
          quantity: null,
          price: undefined,
          priceSource: undefined,
        })),
      )

      // Fetch TPF balance
      const fetchTPFBalance = async () => {
        try {
          console.log(`Fetching TPF balance...`)
          const response = await fetch(`/api/token-balance?address=${walletAddress}&_=${Date.now()}`)

          if (!response.ok) {
            const errorData = await response.json()
            throw new Error(errorData.error || "Failed to fetch TPF balance")
          }

          const data = await response.json()
          console.log(`TPF balance data:`, data)

          if (data.error) {
            throw new Error(data.error)
          }

          // Format balance with 2 decimal places
          const formattedBalance = data.balance.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })

          // Fetch TPF price from API
          const priceResponse = await fetch(`/api/token-price?symbol=TPF`)
          const priceData = await priceResponse.json()

          return {
            quantity: formattedBalance,
            error: undefined,
            loading: false,
            price: priceData.price,
            priceSource: priceData.source,
          }
        } catch (error) {
          console.error(`Error fetching TPF balance:`, error)
          return {
            quantity: null,
            error: error instanceof Error ? error.message : "Failed to fetch TPF balance",
            loading: false,
          }
        }
      }

      // Fetch WLD balance using the new API with ethers.js
      const fetchWLDBalance = async () => {
        try {
          console.log(`Fetching WLD balance using ethers.js...`)
          const response = await fetch(`/api/ethers-wld-balance?address=${walletAddress}&_=${Date.now()}`)
          const data = await response.json()

          console.log(`WLD balance response:`, data)

          if (data.error) {
            return {
              quantity: null,
              error: data.error,
              details: data.details,
              loading: false,
            }
          }

          // Format balance with 2 decimal places
          const formattedBalance = data.balance.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })

          // Fetch WLD price from API
          const priceResponse = await fetch(`/api/token-price?symbol=WLD`)
          const priceData = await priceResponse.json()

          return {
            quantity: formattedBalance,
            error: undefined,
            details: undefined,
            loading: false,
            price: priceData.price,
            priceSource: priceData.source,
          }
        } catch (error) {
          console.error(`Error fetching WLD balance:`, error)
          return {
            quantity: null,
            error: error instanceof Error ? error.message : "Failed to fetch WLD balance",
            loading: false,
          }
        }
      }

      // Fetch balances in parallel
      const [tpfResult, wldResult] = await Promise.all([fetchTPFBalance(), fetchWLDBalance()])

      // Update tokens with results
      setTokens((prev) => [
        {
          ...prev[0],
          ...tpfResult,
        },
        {
          ...prev[1],
          ...wldResult,
        },
      ])

      setIsLoading(false)
    }

    fetchTokenBalances()
  }, [walletAddress, refreshTrigger])

  const handleRefresh = () => {
    setRefreshTrigger((prev) => prev + 1)
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopySuccess(true)
      setTimeout(() => setCopySuccess(false), 2000)
    } catch (err) {
      console.error("Failed to copy: ", err)
    }
  }

  const handleSendClick = (token: TokenInfo) => {
    setSelectedToken(token)
    if (token.symbol === "TPF") {
      setIsSendTPFModalOpen(true)
    } else {
      setIsSendModalOpen(true)
    }
  }

  const handleReceiveClick = (token: TokenInfo) => {
    setSelectedToken(token)
    setIsReceiveModalOpen(true)
  }

  const handleTokenClick = (token: TokenInfo) => {
    setSelectedToken(token)
    setIsDetailModalOpen(true)
  }

  const handleTransactionSuccess = () => {
    // Refresh token balances after successful transaction
    setTimeout(() => {
      handleRefresh()
    }, 5000) // Wait 5 seconds before refreshing to allow transaction to be processed
  }

  // Filter tokens to only show those with a balance
  const tokensWithBalance = tokens.filter((token) => token.quantity !== null && Number.parseFloat(token.quantity) > 0)
  const tokensWithoutBalance = tokens.filter(
    (token) => token.quantity === null || Number.parseFloat(token.quantity) === 0,
  )

  return (
    <>
      <div className="bg-gray-900/80 backdrop-blur-sm rounded-xl sm:rounded-2xl shadow-xl p-4 sm:p-6 border border-gray-700">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-base sm:text-lg font-medium text-gray-300">{t("my_tokens", "My Tokens")}</h3>
          <button
            onClick={handleRefresh}
            className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded transition-colors flex items-center"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                {t("refreshing", "Refreshing...")}
              </>
            ) : (
              <>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 mr-1"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                  />
                </svg>
                {t("refresh", "Refresh")}
              </>
            )}
          </button>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="p-3 sm:p-4 rounded-lg bg-gray-800/80 backdrop-blur-sm animate-pulse">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full mr-3 sm:mr-4 bg-gray-700"></div>
                    <div>
                      <div className="h-4 bg-gray-700 rounded w-16 mb-2"></div>
                      <div className="h-3 bg-gray-700 rounded w-24"></div>
                    </div>
                  </div>
                  <div className="h-6 w-16 bg-gray-700 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : tokensWithBalance.length > 0 ? (
          <div className="space-y-3">
            {tokensWithBalance.map((token) => (
              <div
                key={token.symbol}
                className="p-3 sm:p-4 rounded-lg bg-gray-800/80 backdrop-blur-sm hover:bg-gray-800 transition-colors cursor-pointer"
                onClick={() => handleTokenClick(token)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full mr-3 sm:mr-4 overflow-hidden bg-gray-700 flex items-center justify-center">
                      <Image
                        src={token.logo || "/placeholder.svg"}
                        alt={`${token.symbol} logo`}
                        width={48}
                        height={48}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="font-medium text-white text-base sm:text-lg">{token.symbol}</div>
                      <div className="text-xs sm:text-sm text-gray-400">{token.name}</div>
                      {/* Remove price display */}
                      {token.error && (
                        <div className="text-xs text-red-400 mt-1">
                          {t("error", "Error:")} {token.error}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    {token.loading ? (
                      <div className="h-6 w-16 bg-gray-700 rounded animate-pulse"></div>
                    ) : token.quantity ? (
                      <div className="font-bold text-white text-lg sm:text-xl">{token.quantity}</div>
                    ) : (
                      <div className="text-red-400 text-sm">{t("unavailable_token", "Unavailable")}</div>
                    )}
                  </div>
                </div>

                {/* Add token action buttons */}
                <div className="mt-3 grid grid-cols-2 gap-2" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      handleSendClick(token)
                    }}
                    className="py-1 px-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white flex items-center justify-center transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <path d="M12 19V5" />
                      <path d="m5 12 7-7 7 7" />
                    </svg>
                    {t("send", "Send")}
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      handleReceiveClick(token)
                    }}
                    className="py-1 px-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white flex items-center justify-center transition-colors"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <path d="M12 5v14" />
                      <path d="m5 12 7 7 7-7" />
                    </svg>
                    {t("receive", "Receive")}
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-12 w-12 mx-auto text-gray-500 mb-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            <h3 className="text-lg font-medium text-white mb-2">{t("no_tokens_found", "No Tokens Found")}</h3>
            <p className="text-gray-400 mb-4">
              {t(
                "no_tokens_description",
                'You don\'t have any tokens in your wallet yet. Use the "Receive" button to get started.',
              )}
            </p>
            <div className="flex justify-center space-x-2">
              {tokens.map((token) => (
                <button
                  key={token.symbol}
                  onClick={() => handleReceiveClick(token)}
                  className="px-3 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors flex items-center"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-1"
                  >
                    <path d="M12 5v14" />
                    <path d="m5 12 7 7 7-7" />
                  </svg>
                  {t("receive_token", "Receive")} {token.symbol}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Send Token Modal for WLD */}
      {selectedToken && selectedToken.symbol === "WLD" && (
        <SendTokenModal
          isOpen={isSendModalOpen}
          onClose={() => setIsSendModalOpen(false)}
          walletAddress={walletAddress}
          tokenSymbol={selectedToken.symbol}
          tokenLogo={selectedToken.logo}
          tokenName={selectedToken.name}
          onSuccess={handleTransactionSuccess}
        />
      )}

      {/* Send TPF Modal */}
      {selectedToken && selectedToken.symbol === "TPF" && (
        <SendTPFModal
          isOpen={isSendTPFModalOpen}
          onClose={() => setIsSendTPFModalOpen(false)}
          walletAddress={walletAddress}
          tokenLogo={selectedToken.logo}
          onSuccess={handleTransactionSuccess}
        />
      )}

      {/* Receive Token Modal */}
      {selectedToken && (
        <ReceiveTokenModal
          isOpen={isReceiveModalOpen}
          onClose={() => setIsReceiveModalOpen(false)}
          walletAddress={walletAddress}
          tokenSymbol={selectedToken.symbol}
          tokenLogo={selectedToken.logo}
          tokenName={selectedToken.name}
        />
      )}

      {/* Token Detail Modal with Chart */}
      {selectedToken && (
        <TokenDetailModal
          isOpen={isDetailModalOpen}
          onClose={() => setIsDetailModalOpen(false)}
          token={selectedToken}
          walletAddress={walletAddress}
          onSwap={handleTransactionSuccess}
        />
      )}
    </>
  )
}
