"use client"

import { useState, useEffect } from "react"
import { MiniKit } from "@worldcoin/minikit-js"
import { ethers } from "ethers"
import { useLanguage } from "@/lib/languageContext"

// Atualizar o endereço do contrato da loteria
const LOTTERY_CONTRACT_ADDRESS = "0xb2271682333dE3f851c7522427E487a565dA6b16"
const TPF_TOKEN_ADDRESS = "0x834a73c0a83F3BCe349A116FFB2A4c2d1C651E45"

// Atualizar o ABI para o novo contrato
const LOTTERY_ABI = [
  {
    inputs: [],
    name: "BURN_PERCENTAGE",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "MIN_ENTRY",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "MIN_ENTRY_TPF",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "WEEKLY_INTERVAL",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "accumulatedPrize",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "executeManualDraw",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "getContractBalance",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "getCurrentParticipants",
    outputs: [
      {
        components: [
          {
            internalType: "address",
            name: "wallet",
            type: "address",
          },
          {
            internalType: "uint256",
            name: "tickets",
            type: "uint256",
          },
        ],
        internalType: "struct AutomaticTPFLottery.Participant[]",
        name: "",
        type: "tuple[]",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "getDebugInfo",
    outputs: [
      {
        internalType: "uint256",
        name: "tpfBalance",
        type: "uint256",
      },
      {
        internalType: "uint256",
        name: "prize",
        type: "uint256",
      },
      {
        internalType: "uint256",
        name: "participantCount",
        type: "uint256",
      },
      {
        internalType: "uint8",
        name: "decimals",
        type: "uint8",
      },
      {
        internalType: "uint256",
        name: "minEntry",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "getNextDrawTime",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "getTimeUntilNextDraw",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "lastDraw",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
    ],
    name: "manualBurn",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "participant",
        type: "address",
      },
      {
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
    ],
    name: "manualRegisterParticipant",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "owner",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "renounceOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "",
        type: "address",
      },
      {
        internalType: "address",
        name: "from",
        type: "address",
      },
      {
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
      {
        internalType: "bytes",
        name: "",
        type: "bytes",
      },
    ],
    name: "tokensReceived",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "totalBurned",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "newOwner",
        type: "address",
      },
    ],
    name: "transferOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "amount",
        type: "uint256",
      },
    ],
    name: "withdrawTokens",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
]

// ERC20 ABI for token interactions
const ERC20_ABI = [
  {
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    name: "approve",
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [{ name: "account", type: "address" }],
    name: "balanceOf",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "decimals",
    outputs: [{ name: "", type: "uint8" }],
    stateMutability: "view",
    type: "function",
  },
]

// Type for participant
type Participant = {
  wallet: string
  tickets: string
}

export function Lottery({ userAddress }: { userAddress: string }) {
  const { t } = useLanguage()
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [txHash, setTxHash] = useState<string | null>(null)
  const [refreshTrigger, setRefreshTrigger] = useState(0)
  // Add a new state for the info modal
  const [showInfoModal, setShowInfoModal] = useState(false)

  // Lottery state
  const [lotteryInfo, setLotteryInfo] = useState<{
    minEntryTPF: string
    burnPercentage: string
    accumulatedPrize: string
    contractBalance: string
    nextDrawTime: string
    timeUntilNextDraw: string
    totalBurned: string
    participants: Participant[]
    userTickets: string
    userParticipating: boolean
    decimals: number
  }>({
    minEntryTPF: "0",
    burnPercentage: "0",
    accumulatedPrize: "0",
    contractBalance: "0",
    nextDrawTime: "0",
    timeUntilNextDraw: "0",
    totalBurned: "0",
    participants: [],
    userTickets: "0",
    userParticipating: false,
    decimals: 18,
  })

  // User state
  const [tpfBalance, setTpfBalance] = useState<string>("0")
  const [participationAmount, setParticipationAmount] = useState<string>("")
  const [countdown, setCountdown] = useState<string>("")

  const fetchLotteryData = async () => {
    if (!userAddress) return

    console.log("Manually fetching lottery data...")
    setError(null)

    try {
      // Create provider
      let provider
      try {
        provider = new ethers.JsonRpcProvider("https://worldchain-mainnet.g.alchemy.com/public")
      } catch (error) {
        console.error("Failed to connect to primary RPC, trying fallback:", error)
        provider = new ethers.JsonRpcProvider("https://rpc.worldcoin.org")
      }

      // Get contracts
      const lotteryContract = new ethers.Contract(LOTTERY_CONTRACT_ADDRESS, LOTTERY_ABI, provider)
      const tpfContract = new ethers.Contract(TPF_TOKEN_ADDRESS, ERC20_ABI, provider)

      // Fetch lottery data
      const [
        minEntryTPF,
        burnPercentage,
        accumulatedPrize,
        contractBalance,
        participants,
        debugInfo,
        nextDrawTime,
        timeUntilNextDraw,
        totalBurned,
        userBalance,
      ] = await Promise.all([
        lotteryContract.MIN_ENTRY_TPF(),
        lotteryContract.BURN_PERCENTAGE(),
        lotteryContract.accumulatedPrize(),
        lotteryContract.getContractBalance(),
        lotteryContract.getCurrentParticipants(),
        lotteryContract.getDebugInfo(),
        lotteryContract.getNextDrawTime(),
        lotteryContract.getTimeUntilNextDraw(),
        lotteryContract.totalBurned(),
        tpfContract.balanceOf(userAddress),
      ])

      // Get decimals from debug info
      const decimals = Number(debugInfo[3])

      // Format data
      const formattedMinEntryTPF = minEntryTPF.toString()
      const formattedBurnPercentage = burnPercentage.toString()
      const formattedAccumulatedPrize = ethers.formatUnits(accumulatedPrize, decimals)
      const formattedContractBalance = ethers.formatUnits(contractBalance, decimals)
      const formattedTotalBurned = ethers.formatUnits(totalBurned, decimals)
      const formattedUserBalance = ethers.formatUnits(userBalance, decimals)

      console.log("Fetched data:", {
        accumulatedPrize: formattedAccumulatedPrize,
        contractBalance: formattedContractBalance,
        participantsCount: participants.length,
      })

      // Format participants
      const formattedParticipants = participants.map((p: any) => ({
        wallet: p[0],
        tickets: p[1].toString(),
      }))

      // Check if user is participating
      let userTickets = "0"
      const userParticipating = formattedParticipants.some((p: Participant) => {
        if (p.wallet.toLowerCase() === userAddress.toLowerCase()) {
          userTickets = p.tickets
          return true
        }
        return false
      })

      setTpfBalance(formattedUserBalance)
      setLotteryInfo({
        minEntryTPF: formattedMinEntryTPF,
        burnPercentage: formattedBurnPercentage,
        accumulatedPrize: formattedAccumulatedPrize,
        contractBalance: formattedContractBalance,
        nextDrawTime: nextDrawTime.toString(),
        timeUntilNextDraw: timeUntilNextDraw.toString(),
        totalBurned: formattedTotalBurned,
        participants: formattedParticipants,
        userTickets,
        userParticipating,
        decimals,
      })
    } catch (err) {
      console.error("Error fetching lottery data:", err)
      setError("Error connecting to lottery contract. Please try refreshing.")
    }
  }

  // Fetch lottery data
  useEffect(() => {
    setIsLoading(true)
    fetchLotteryData().finally(() => setIsLoading(false))

    // Refresh data every 30 seconds
    const interval = setInterval(() => {
      fetchLotteryData()
    }, 30000)

    return () => clearInterval(interval)
  }, [userAddress, refreshTrigger])

  // Update countdown timer
  useEffect(() => {
    if (!lotteryInfo.timeUntilNextDraw || lotteryInfo.timeUntilNextDraw === "0") {
      setCountdown("Draw ready!")
      return
    }

    const updateCountdown = () => {
      const timeLeft = Number(lotteryInfo.timeUntilNextDraw)
      if (timeLeft <= 0) {
        setCountdown("Draw ready!")
        return
      }

      const days = Math.floor(timeLeft / (24 * 60 * 60))
      const hours = Math.floor((timeLeft % (24 * 60 * 60)) / (60 * 60))
      const minutes = Math.floor((timeLeft % (60 * 60)) / 60)
      const seconds = timeLeft % 60

      setCountdown(
        `${days}d ${hours.toString().padStart(2, "0")}h ${minutes.toString().padStart(2, "0")}m ${seconds
          .toString()
          .padStart(2, "0")}s`,
      )
    }

    // Update immediately
    updateCountdown()

    // And then every second
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [lotteryInfo.timeUntilNextDraw])

  const handleParticipate = async () => {
    if (!participationAmount || Number(participationAmount) <= 0) {
      setError("Please enter an amount")
      return
    }

    const minEntry = Number(lotteryInfo.minEntryTPF)
    if (Number(participationAmount) < minEntry) {
      setError(`Minimum entry is ${minEntry} TPF`)
      return
    }

    setIsProcessing(true)
    setError(null)
    setSuccess(null)
    setTxHash(null)

    try {
      if (!MiniKit.isInstalled()) {
        throw new Error("MiniKit is not installed")
      }

      // Convert amount to wei
      const amountInWei = ethers.parseUnits(participationAmount, lotteryInfo.decimals).toString()
      console.log(`Participating with ${participationAmount} TPF (${amountInWei} wei)`)

      // Send TPF tokens to the lottery contract
      const transferResponse = await MiniKit.commandsAsync.sendTransaction({
        transaction: [
          {
            address: TPF_TOKEN_ADDRESS,
            abi: [
              {
                inputs: [
                  { name: "to", type: "address" },
                  { name: "amount", type: "uint256" },
                ],
                name: "transfer",
                outputs: [{ name: "", type: "bool" }],
                stateMutability: "nonpayable",
                type: "function",
              },
            ],
            functionName: "transfer",
            args: [LOTTERY_CONTRACT_ADDRESS, amountInWei],
          },
        ],
      })

      console.log("Transfer response:", transferResponse.finalPayload)

      if (transferResponse.finalPayload.status === "error") {
        throw new Error(
          transferResponse.finalPayload.message ||
            transferResponse.finalPayload.description ||
            "Failed to transfer tokens",
        )
      }

      setSuccess("Successfully entered the lottery! Refreshing data...")
      setTxHash(transferResponse.finalPayload.transaction_id || null)
      setParticipationAmount("")

      // Implement more aggressive refresh strategy
      // First refresh immediately
      await fetchLotteryData()

      // Then refresh a few more times with delays
      setTimeout(() => fetchLotteryData(), 3000) // 3 seconds
      setTimeout(() => fetchLotteryData(), 6000) // 6 seconds
      setTimeout(() => fetchLotteryData(), 15000) // 15 seconds

      // Also trigger the general refresh
      setRefreshTrigger((prev) => prev + 1)
    } catch (err) {
      console.error("Error participating in lottery:", err)
      const errorMessage = err instanceof Error ? err.message : "Failed to participate in lottery"
      setError(errorMessage)
    } finally {
      setIsProcessing(false)
    }
  }

  // Format date
  const formatDate = (timestamp: string) => {
    if (!timestamp) return "-"
    return new Date(Number(timestamp) * 1000).toLocaleString()
  }

  // Format address
  const formatAddress = (address: string) => {
    if (!address) return "-"
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  // Calculate tickets percentage
  const calculateTicketPercentage = (tickets: string) => {
    const totalTickets = lotteryInfo.participants.reduce((acc, p) => acc + Number(p.tickets), 0)
    if (totalTickets === 0) return "0%"
    return `${((Number(tickets) / totalTickets) * 100).toFixed(2)}%`
  }

  return (
    <div className="bg-gradient-to-b from-gray-900/90 to-purple-950/90 backdrop-blur-sm rounded-2xl p-5 max-w-md mx-auto shadow-xl border border-purple-700/50 animate-fadeIn">
      {/* Flashy Header */}
      <div className="text-center mb-6 relative">
        {/* Animated background glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-pink-600/20 rounded-xl blur-xl animate-pulse"></div>

        <div className="relative">
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 animate-gradient">
            {t("lottery_title", "TPF LOTTERY")}
          </h1>
          <div className="h-1 w-32 mx-auto bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 rounded-full mb-3"></div>

          {/* Animated stars */}
          <div className="absolute -top-4 -left-2 text-yellow-300 animate-pulse text-xl">✨</div>
          <div className="absolute -top-2 -right-1 text-yellow-300 animate-pulse delay-300 text-xl">✨</div>

          <p className="text-sm text-gray-300 max-w-xs mx-auto">
            <span className="font-bold text-purple-300">{t("enter_now", "Enter now")}</span>{" "}
            {t("for_chance_to_win", "for your chance to win big! More TPF = higher chance!")}
          </p>

          {/* Info Icon */}
          <div className="fixed bottom-4 right-4 z-20">
            <button
              onClick={() => setShowInfoModal(true)}
              className="bg-purple-700 hover:bg-purple-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-110"
              aria-label={t("how_it_works_info", "How It Works")}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* How It Works Modal */}
      {showInfoModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
          onClick={() => setShowInfoModal(false)}
        >
          <div
            className="bg-gradient-to-r from-blue-900/90 to-purple-900/90 backdrop-blur-sm rounded-lg p-5 max-w-md mx-auto border border-blue-600/50 shadow-xl animate-fadeIn"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-white flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 mr-2 text-purple-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                {t("how_it_works_info", "How It Works")}
              </h3>
              <button
                onClick={() => setShowInfoModal(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="space-y-3 text-sm text-gray-300">
              <p className="flex items-start">
                <span className="text-purple-400 font-bold mr-2 mt-0.5">1.</span>
                <span>
                  {t("how_it_works_point1", "Enter the lottery by sending TPF tokens (min {minEntry} TPF)").replace(
                    "{minEntry}",
                    lotteryInfo.minEntryTPF,
                  )}
                </span>
              </p>
              <p className="flex items-start">
                <span className="text-purple-400 font-bold mr-2 mt-0.5">2.</span>
                <span>
                  {t("how_it_works_point2", "Each {minEntry} TPF gives you 1 ticket").replace(
                    "{minEntry}",
                    lotteryInfo.minEntryTPF,
                  )}
                </span>
              </p>
              <p className="flex items-start">
                <span className="text-purple-400 font-bold mr-2 mt-0.5">3.</span>
                <span>{t("how_it_works_point3", "More tickets = higher chance to win")}</span>
              </p>
              <p className="flex items-start">
                <span className="text-purple-400 font-bold mr-2 mt-0.5">4.</span>
                <span>{t("how_it_works_point4", "Winner is selected randomly every week")}</span>
              </p>
              <p className="flex items-start">
                <span className="text-purple-400 font-bold mr-2 mt-0.5">5.</span>
                <span>
                  {t("how_it_works_point5", "Winner gets {winnerPercent}% of the pool, {burnPercent}% is burned")
                    .replace("{winnerPercent}", (100 - Number(lotteryInfo.burnPercentage)).toString())
                    .replace("{burnPercent}", lotteryInfo.burnPercentage)}
                </span>
              </p>
              <p className="flex items-start">
                <span className="text-purple-400 font-bold mr-2 mt-0.5">6.</span>
                <span>{t("all_weeks_have_one", "All weeks have one lottery")}</span>
              </p>
            </div>
            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setShowInfoModal(false)}
                className="px-4 py-2 bg-purple-700 hover:bg-purple-600 text-white rounded-lg transition-colors"
              >
                {t("close", "Close")}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Big Winner Section */}
      <div className="bg-gradient-to-r from-purple-900/80 to-blue-900/80 backdrop-blur-sm rounded-xl p-4 mb-6 border border-purple-500/50 shadow-lg transform hover:scale-[1.02] transition-all duration-300">
        <div className="relative overflow-hidden">
          {/* Animated shine effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer bg-size-200"></div>

          <div className="text-center py-2">
            <h2 className="text-xl font-bold text-yellow-300 mb-1 flex items-center justify-center">
              <span className="text-2xl mr-1">🏆</span> {t("big_winner", "BIG WINNER")}{" "}
              <span className="text-2xl ml-1">🏆</span>
            </h2>
            <div className="text-3xl font-extrabold text-white mb-2">
              {Number(lotteryInfo.contractBalance).toLocaleString()} TPF
            </div>
            <p className="text-sm text-purple-200">{t("could_be_yours_in", "Could be yours in:")}</p>
            <div className="text-xl font-mono text-yellow-300 mt-1 bg-purple-900/50 rounded-lg py-1 px-3 inline-block">
              {countdown === "Draw ready!" ? t("draw_ready", "Draw ready!") : countdown}
            </div>

            {/* Adicionar a chance do usuário abaixo do temporizador */}
            <div className="mt-2 text-sm">
              <span
                className={`bg-purple-900/50 rounded-lg py-1 px-3 ${lotteryInfo.userParticipating ? "text-green-300" : "text-gray-300"}`}
              >
                {t("chance", "Chance")}:{" "}
                {lotteryInfo.userParticipating ? calculateTicketPercentage(lotteryInfo.userTickets) : "0%"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Total Burned Section with Fire Animation */}
      <div className="bg-gradient-to-b from-gray-900/90 via-red-900/40 to-orange-900/30 backdrop-blur-sm rounded-lg p-4 mb-4 border border-orange-600/50 shadow-lg overflow-hidden relative">
        {/* Fire animation elements */}
        <div className="absolute bottom-0 left-0 w-full h-1/2 overflow-hidden">
          <div className="absolute bottom-0 left-1/4 w-2 h-8 bg-orange-500 rounded-t-lg animate-pulse opacity-70"></div>
          <div className="absolute bottom-0 left-1/3 w-3 h-12 bg-orange-400 rounded-t-lg animate-pulse delay-100 opacity-60"></div>
          <div className="absolute bottom-0 left-1/2 w-4 h-16 bg-yellow-500 rounded-t-lg animate-pulse delay-200 opacity-80"></div>
          <div className="absolute bottom-0 left-2/3 w-3 h-10 bg-red-500 rounded-t-lg animate-pulse delay-300 opacity-70"></div>
          <div className="absolute bottom-0 left-3/4 w-2 h-6 bg-orange-600 rounded-t-lg animate-pulse delay-150 opacity-60"></div>
        </div>

        <div className="relative z-10">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-xl font-bold text-white flex items-center">
              <span className="text-orange-500 mr-2">🔥</span>
              {t("total_burned", "Total Burned")}
              <span className="text-orange-500 ml-2">🔥</span>
            </h3>
            <button
              onClick={() => {
                setSuccess(t("refreshing_data", "Refreshing data..."))
                fetchLotteryData().then(() => {
                  setSuccess(null)
                })
              }}
              className="text-xs bg-orange-700 hover:bg-orange-600 text-white px-2 py-1 rounded-full transition-colors flex items-center shadow-md hover:shadow-orange-500/30"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-3 w-3 mr-1"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
              {t("refresh", "Refresh")}
            </button>
          </div>

          <div className="text-center py-4">
            <div className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 via-orange-500 to-red-600 animate-pulse">
              {Number(lotteryInfo.totalBurned).toLocaleString()} TPF
            </div>
            <p className="text-orange-300 mt-2">{t("tokens_removed", "Tokens forever removed from circulation")}</p>
          </div>

          {/* Animated flames at the bottom */}
          <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-orange-600/40 to-transparent"></div>
        </div>
      </div>

      {/* Error and Success Messages */}
      {error && (
        <div className="bg-red-900/30 text-red-300 text-sm p-3 rounded-lg mb-4 border border-red-800/50 animate-fadeIn">
          {error}
        </div>
      )}

      {/* Update the success message section to remove the Check Participation button and simplify the display */}
      {/* Replace the entire success message section with this: */}
      {success && (
        <div className="bg-gradient-to-r from-green-900/40 to-blue-900/40 text-green-300 text-sm p-4 rounded-lg mb-4 border border-green-500/50 animate-fadeIn">
          {success.includes("Successfully entered") ? (
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-300 mb-2 animate-pulse">
                🍀 {t("good_luck", "Good Luck!")} 🍀
              </div>
              <p className="text-green-300">{t("success_entered", "Successfully entered the lottery!")}</p>
              {txHash && (
                <div className="mt-3">
                  <a
                    href={`https://worldscan.org/tx/${txHash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs bg-blue-900/50 hover:bg-blue-800/70 text-blue-300 px-3 py-1.5 rounded transition-colors"
                  >
                    {t("view_on_worldscan", "View on WorldScan")}
                  </a>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center">{success}</div>
          )}
        </div>
      )}

      {/* Participation Form */}
      <div className="bg-gradient-to-r from-blue-900/70 to-purple-900/70 backdrop-blur-sm rounded-lg p-4 mb-4 border border-blue-600/50 shadow-lg transform hover:shadow-purple-500/20 hover:border-purple-500/70 transition-all duration-300">
        <h3 className="text-xl font-bold text-white mb-3 flex items-center justify-center">
          <span className="text-yellow-300 mr-2">🎮</span> {t("play_now", "PLAY NOW")}{" "}
          <span className="text-yellow-300 ml-2">🎮</span>
        </h3>
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-purple-300 mb-1">
              {t("your_tpf_balance", "Your TPF Balance")}
            </label>
            <div className="w-full px-3 py-2 bg-gray-800/80 border border-purple-700/50 rounded-lg text-white font-bold">
              {Number(tpfBalance).toLocaleString()} TPF
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-purple-300 mb-1">
              {t("amount_to_enter", "Amount to Enter")}
            </label>
            <input
              type="number"
              value={participationAmount}
              onChange={(e) => setParticipationAmount(e.target.value)}
              placeholder="0.0"
              className="w-full px-3 py-2 bg-gray-800/80 border border-purple-700/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <p className="text-xs text-purple-300 mt-1">
              {t("minimum_entry", "Minimum entry")} - {lotteryInfo.minEntryTPF} TPF
            </p>
            <p className="text-xs text-purple-300 mt-1">
              {t("more_tpf_higher_chance", "Quanto mais TPF enviares, mais hipotese tens de ganhar!")}
            </p>
          </div>

          <button
            onClick={handleParticipate}
            disabled={
              isProcessing ||
              Number(participationAmount) <= 0 ||
              Number(participationAmount) < Number(lotteryInfo.minEntryTPF) ||
              Number(participationAmount) > Number(tpfBalance)
            }
            className={`w-full py-3 px-4 rounded-lg font-bold text-lg transition-all duration-300 flex items-center justify-center
              ${
                isProcessing
                  ? "bg-purple-700 text-white cursor-wait"
                  : Number(participationAmount) <= 0 ||
                      Number(participationAmount) < Number(lotteryInfo.minEntryTPF) ||
                      Number(participationAmount) > Number(tpfBalance)
                    ? "bg-gray-700 text-gray-400 cursor-not-allowed"
                    : "bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:shadow-lg hover:shadow-purple-600/30 hover:scale-[1.02] transform"
              }`}
          >
            {isProcessing ? (
              <div className="flex items-center">
                <svg
                  className="animate-spin h-5 w-5 mr-2 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                {t("processing", "Processing...")}
              </div>
            ) : (
              <>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 mr-2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                {t("enter_now_button", "ENTER NOW!")}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
